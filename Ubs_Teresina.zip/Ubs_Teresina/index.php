<?php
// Variável para exibir mensagens de sucesso ou erro
$mensagem = "";

// 1. VERIFICA SE O FORMULÁRIO FOI ENVIADO (MÉTODO POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 2. CONFIGURAÇÕES DO BANCO DE DADOS
    $servidor = "localhost"; // Servidor local (XAMPP)
    $usuario_db = "root";     // Usuário padrão do XAMPP
    $senha_db = "";           // Senha padrão do XAMPP (vazia)
    $banco = "ubs_cadastro";  // O banco de dados que criamos

    // Cria a conexão
    $conn = new mysqli($servidor, $usuario_db, $senha_db, $banco);

    // Verifica a conexão
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // 3. PEGA OS DADOS DO FORMULÁRIO (VIA $_POST)
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];

    // 4. PROCESSA OS ARQUIVOS (VIA $_FILES)
    $pasta_uploads = "uploads/"; // A pasta que criamos

    // --- Processa Documento com Foto (RG/CNN) ---
    // basename() previne ataques de "directory traversal"
    $nome_arquivo_doc = basename($_FILES["documento"]["name"]);
    $caminho_doc = $pasta_uploads . $nome_arquivo_doc;
    move_uploaded_file($_FILES["documento"]["tmp_name"], $caminho_doc);

    // --- Processa Cartão do SUS ---
    $nome_arquivo_sus = basename($_FILES["cartao-sus"]["name"]);
    $caminho_sus = $pasta_uploads . $nome_arquivo_sus;
    move_uploaded_file($_FILES["cartao-sus"]["tmp_name"], $caminho_sus);

    // --- Processa Comprovante de Endereço ---
    $nome_arquivo_end = basename($_FILES["comprovante-endereco"]["name"]);
    $caminho_end = $pasta_uploads . $nome_arquivo_end;
    move_uploaded_file($_FILES["comprovante-endereco"]["tmp_name"], $caminho_end);

    // 5. INSERE OS DADOS NO BANCO DE DADOS (COM PREPARED STATEMENTS)
    // Usar "prepared statements" (o '?'') previne injeção de SQL
    $stmt = $conn->prepare("INSERT INTO pacientes (nome, cpf, telefone, doc_foto, cartao_sus, comprovante_endereco) VALUES (?, ?, ?, ?, ?, ?)");
    
    // "ssssss" significa que estamos enviando 6 variáveis do tipo "string"
    $stmt->bind_param("ssssss", $nome, $cpf, $telefone, $caminho_doc, $caminho_sus, $caminho_end);

    // 6. EXECUTA E DÁ FEEDBACK
    if ($stmt->execute()) {
        $mensagem = "<div class='mensagem sucesso'>Cadastro realizado com sucesso!</div>";
    } else {
        $mensagem = "<div class='mensagem erro'>Erro ao cadastrar: " . $stmt->error . "</div>";
    }

    // Fecha a conexão
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <title>UBS</title>
</head>
<body>

    <header>
        <div id="menu">
            <h1>FUNDAÇÃO MUNICIPAL DE SAÚDE - FMS TERESINA</h1>
        </div>
        <div id="titulo">
            <h2>CADASTRO</h2>
        </div>
    </header>

    <main id="corpo">
        <div>
            <section id="formulario">

                <?php echo $mensagem; ?>

                <form id="inf" method="POST" action="index.php" enctype="multipart/form-data">
                    <div class="registro">
                        <label for="name">NOME:</label>
                        <input type="text" name="nome" id="nome" placeholder="Digite seu nome" required>
                    </div>

                    <div class="registro">
                        <label for="cpf">CPF:</label>
                        <input type="text" name="cpf" placeholder="000.000.000-00" inputmode="numeric" maxlength="14" required class="cadastro">
                    </div>

                    <div class="registro">
                        <label for="telefone">TELEFONE:</label>
                        <input type="tel" name="telefone" placeholder="(86) 99999-9999" inputmode="tel" 
                        maxlength="15" required class="cadastro">
                    </div>

                    <div class="docuc-foto">
                        <label for="documento">ENVIE UM DOCUMENTO COM FOTO (RG ou CNN):</label>
                        <input type="file" name="documento" id="rg" accept="image/*" required class="foto">
                    </div>

                    <div class="docuc-foto">
                        <label for="cartao-sus">ENVIE UMA FOTO OU ARQUIVO DO <strong>CARTÃO DO SUS</strong>:</label>
                        <input type="file" name="cartao-sus" accept=".jpg, .jpeg, .png, .pdf" required class="foto">
                        <small>Formatos aceitos: JPG, PNG ou PDF (máx. 5 MB)</small>
                    </div>

                    <div class="docuc-foto">
                        <label for="comprovante-endereco">ENVIE O <strong>COMPROVANTE DE ENDEREÇO (conta de luz, água, internet, etc)</strong>:</label>
                        <input type="file" name="comprovante-endereco" accept=".jpg, .jpeg, .png, .pdf" required class="foto">
                        <small>Formatos aceitos: JPG, PNG ou PDF (máx. 5 MB)</small>
                    </div>

                    <div id="botoes">
                        <button type="submit">Enviar</button>
                        <button type="reset">Limpar</button>
                    </div>
                </form>
            </section>
        </div>
    </main>

    <footer>
        <h3>Fundação Municipal de Saúde de Teresina - FMS</h1>
        <p>A FMS tem por objetivo o planejamento e a execução da política de saúde do Município de Teresina, desenvolvendo atividades integradas de prevenção, proteção, promoção e recuperação da saúde.</p>
      <div id = "contato">       
            <p><i class="fa-solid fa-house"></i> Rua Governador Artur de Vasconcelos, 3015 - Aeroporto, Teresina - PI CEP: 64002-530</p>
            <p><i class="fa-solid fa-phone"></i><a href="tel:+558632288700">(+55) 86 3228-8700</a></p>
            <p><i class="fa-solid fa-envelope"></i><a href="mailto:ouvidoriasus@pmt.pi.gov.br" class="cont-esp">ouvidoriasus@pmt.pi.gov.br</a></p>
            <p><i class="fa-solid fa-location-dot"></i><a href="http://www.google.com/maps?q=Rua+Governador+Artur+de+Vasconcelos,+3015,+Teresina" target="_blank" class="cont-esp">Encontre no Google Maps</a></p>
        </div>
        <p>Copyright © 2025, Todos os direitos reservados - Desenvolvido por GTI-FMS</p>
    </footer>
</body>
</html>